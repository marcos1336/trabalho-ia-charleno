// Exibe uma mensagem no console para indicar que o JavaScript da aplicação foi carregado
console.log("IA Criminal carregada");