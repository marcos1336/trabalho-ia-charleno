import os
import json
import re
import requests
from dotenv import load_dotenv
from typing import List, Dict, Any

# Carrega variáveis de ambiente a partir do arquivo .env
load_dotenv()


def _carregar_chaves_api() -> List[str]:
    """
    Carrega as chaves da API do arquivo .env.
    Suporta múltiplos formatos:
    - GEMINI_API_KEY (pode ser uma lista separada por vírgulas)
    - GEMINI_API_KEY_1, GEMINI_API_KEY_2, etc.
    """
    chaves = []
    
    # Tenta carregar GEMINI_API_KEY (pode ser uma lista separada por vírgulas)
    api_key = os.getenv("GEMINI_API_KEY")
    if api_key:
        # Se contém vírgulas, separa em múltiplas chaves
        if "," in api_key:
            chaves.extend([key.strip() for key in api_key.split(",") if key.strip()])
        else:
            chaves.append(api_key.strip())
    
    # Tenta carregar chaves numeradas (GEMINI_API_KEY_1, GEMINI_API_KEY_2, etc.)
    i = 1
    while True:
        chave_num = os.getenv(f"GEMINI_API_KEY_{i}")
        if chave_num:
            chaves.append(chave_num.strip())
            i += 1
        else:
            break
    
    # Remove duplicatas mantendo a ordem
    chaves_unicas = []
    for chave in chaves:
        if chave and chave not in chaves_unicas:
            chaves_unicas.append(chave)
    
    if not chaves_unicas:
        raise RuntimeError(
            "ERRO: Nenhuma GEMINI_API_KEY encontrada no arquivo .env. "
            "Configure GEMINI_API_KEY ou GEMINI_API_KEY_1, GEMINI_API_KEY_2, etc."
        )
    
    return chaves_unicas


# Carrega todas as chaves disponíveis para uso na API Gemini
API_KEYS = _carregar_chaves_api()
# Índice atual para rodízio simples entre as chaves
_current_key_index = 0

# URLs base da API Gemini (tenta v1beta primeiro, depois v1)
GEMINI_API_URLS = [
    "https://generativelanguage.googleapis.com/v1beta/models",
    "https://generativelanguage.googleapis.com/v1/models",
]


def _listar_modelos_disponiveis(api_key: str) -> List[str]:
    """
    Lista os modelos disponíveis na API Gemini que suportam generateContent.
    """
    modelos_disponiveis = []
    
    # URLs para listar modelos (sem o /models no final)
    list_urls = [
        "https://generativelanguage.googleapis.com/v1beta/models",
        "https://generativelanguage.googleapis.com/v1/models",
    ]
    
    for list_url in list_urls:
        try:
            response = requests.get(
                list_url,
                params={"key": api_key}
            )
            
            if response.status_code == 200:
                data = response.json()
                if "models" in data:
                    for model in data["models"]:
                        name = model.get("name", "")
                        # Remove o prefixo "models/" se existir
                        if name.startswith("models/"):
                            name = name[7:]
                        
                        # Verifica se suporta generateContent
                        supported_methods = model.get("supportedGenerationMethods", [])
                        if "generateContent" in supported_methods:
                            modelos_disponiveis.append(name)
                
                if modelos_disponiveis:
                    break  # Se encontrou modelos, não precisa tentar outra versão
        except Exception:
            # Continua tentando outras URLs mesmo se der erro
            continue
    
    return modelos_disponiveis


def _obter_proxima_chave() -> str:
    """
    Retorna a próxima chave da API em rodízio circular (round-robin).
    """
    global _current_key_index
    chave = API_KEYS[_current_key_index]
    _current_key_index = (_current_key_index + 1) % len(API_KEYS)
    return chave


def gerar_caso(genero: str) -> Dict[str, Any]:
    """
    Gera um caso criminal curto usando a API Gemini via REST.
    Retorna um dicionário com: titulo, descricao, pistas (lista), suspeitos (lista), genero.
    """

    try:
        # Prompt que instrui a IA a criar um caso criminal completo em JSON
        prompt = (
            f"Aja como um mestre de RPG criminal. Gere um caso de mistério no gênero {genero}. "
            "Sua resposta deve obrigatoriamente conter duas partes distintas:\n\n"
            "descricao: O texto que o jogador lerá, contendo o crime, a cena e os suspeitos, mas sem revelar o assassino.\n\n"
            "solucao: O 'gabarito' detalhado, revelando quem é o culpado, o motivo e a prova crucial.\n\n"
            "Além disso, inclua também: 'titulo', 'pistas' (uma lista de 3 strings) e 'suspeitos' (uma lista de 3 strings).\n\n"
            "Responda APENAS com o JSON no formato: "
            '{"titulo": "...", "descricao": "...", "solucao": "...", "pistas": [...], "suspeitos": [...]}, '
            "sem texto adicional antes ou depois."
        )

        # Lista padrão de modelos para tentar (mais recentes primeiro)
        # Será substituída por modelos disponíveis se conseguirmos listá-los
        model_names_padrao = [
            "gemini-1.5-flash",
            "gemini-1.5-pro",
            "gemini-pro",
        ]
        
        last_error = None
        chaves_tentadas = set()
        max_tentativas_chaves = len(API_KEYS)
        erro_429_encontrado = False
        modelos_disponiveis_cache = None
        
        # Tenta cada chave da API (rodízio)
        for tentativa_chave in range(max_tentativas_chaves):
            api_key = _obter_proxima_chave()
            
            # Evita tentar a mesma chave múltiplas vezes na mesma requisição
            if api_key in chaves_tentadas:
                continue
            chaves_tentadas.add(api_key)
            
            # Tenta listar modelos disponíveis na primeira tentativa com a chave atual
            if modelos_disponiveis_cache is None:
                try:
                    modelos_disponiveis_cache = _listar_modelos_disponiveis(api_key)
                    if modelos_disponiveis_cache:
                        print(f"✅ Modelos disponíveis encontrados: {', '.join(modelos_disponiveis_cache[:3])}...")
                except Exception:
                    # Se falhar, usa a lista de modelos padrão
                    pass
            
            # Usa modelos disponíveis se encontrados, senão usa a lista padrão
            model_names = modelos_disponiveis_cache if modelos_disponiveis_cache else model_names_padrao
            
            erro_429_encontrado = False
            
            # Tenta cada combinação de versão de API e modelo
            for api_url in GEMINI_API_URLS:
                if erro_429_encontrado:
                    break
                    
                for model_name in model_names:
                    try:
                        # Usa a API REST diretamente para gerar o conteúdo
                        url = f"{api_url}/{model_name}:generateContent"
                        headers = {
                            "Content-Type": "application/json",
                        }
                        payload = {
                            "contents": [{
                                "parts": [{
                                    "text": prompt
                                }]
                            }]
                        }
                        
                        response = requests.post(
                            url,
                            headers=headers,
                            json=payload,
                            params={"key": api_key}
                        )
                        
                        response.raise_for_status()
                        data = response.json()
                        
                        # Extrai o texto da resposta
                        if "candidates" in data and len(data["candidates"]) > 0:
                            candidate = data["candidates"][0]
                            if "content" in candidate and "parts" in candidate["content"]:
                                texto_resposta = candidate["content"]["parts"][0].get("text", "")
                                if texto_resposta:
                                    # Limpa o texto removendo markdown code blocks se existirem
                                    texto_limpo = texto_resposta.strip()
                                    if texto_limpo.startswith("```json"):
                                        texto_limpo = texto_limpo[7:]
                                    if texto_limpo.startswith("```"):
                                        texto_limpo = texto_limpo[3:]
                                    if texto_limpo.endswith("```"):
                                        texto_limpo = texto_limpo[:-3]
                                    texto_limpo = texto_limpo.strip()
                                    
                                    # Converte JSON para dicionário
                                    try:
                                        caso_json = json.loads(texto_limpo)
                                        # Garante que tem todas as chaves necessárias
                                        resultado = {
                                            "genero": genero,
                                            "titulo": caso_json.get("titulo", "Caso Criminal"),
                                            "descricao": caso_json.get("descricao", ""),
                                            "solucao": caso_json.get("solucao", ""),
                                            "pistas": caso_json.get("pistas", []),
                                            "suspeitos": caso_json.get("suspeitos", [])
                                        }
                                        return resultado
                                    except json.JSONDecodeError as e:
                                        print(f"⚠️ Erro ao decodificar JSON: {e}")
                                        print(f"Resposta recebida: {texto_limpo[:200]}...")
                                        # Se falhar, tenta extrair JSON do texto com regex
                                        json_match = re.search(r'\{[^{}]*\}', texto_limpo, re.DOTALL)
                                        if json_match:
                                            try:
                                                caso_json = json.loads(json_match.group())
                                                resultado = {
                                                    "genero": genero,
                                                    "titulo": caso_json.get("titulo", "Caso Criminal"),
                                                    "descricao": caso_json.get("descricao", ""),
                                                    "solucao": caso_json.get("solucao", ""),
                                                    "pistas": caso_json.get("pistas", []),
                                                    "suspeitos": caso_json.get("suspeitos", [])
                                                }
                                                return resultado
                                            except Exception:
                                                pass
                                        # Se nada funcionar, lança o erro original
                                        raise e
                        
                    except requests.exceptions.HTTPError as e:
                        status_code = e.response.status_code if e.response else None
                        
                        # Se for 429 (limite atingido), tenta a próxima chave
                        if status_code == 429:
                            print("⚠️ Limite de requisições atingido (429) para a chave atual. Tentando próxima chave...")
                            last_error = e
                            erro_429_encontrado = True
                            # Sai dos loops de API e modelo para tentar próxima chave
                            break
                        
                        # Se for 404, tenta o próximo modelo
                        if status_code == 404:
                            last_error = e
                            continue
                        
                        # Para outros erros HTTP, propaga
                        raise e
                    
                    except Exception as e:
                        last_error = e
                        # Se o erro não for 404, para de tentar outros modelos
                        if "404" not in str(e) and "NOT_FOUND" not in str(e):
                            raise e
                        continue
            
            # Se não foi 429, não precisa tentar outras chaves (sucesso ou outro erro)
            if not erro_429_encontrado:
                break
        
        # Se chegou aqui, nenhum modelo funcionou ou todas as chaves atingiram limite
        raise last_error if last_error else Exception("Nenhum modelo disponível")

    except Exception as e:
        mensagem = str(e)
        status_code = None
        
        # Tenta extrair o código de status do erro
        if hasattr(e, 'response') and e.response:
            status_code = e.response.status_code

        if status_code == 429 or "429" in mensagem:
            print("⚠️ Limite de requisições atingido (429) em todas as chaves. Aguarde um minuto e tente novamente.")
        else:
            print(f"❌ Erro ao chamar a API Gemini: {mensagem}")

        return None


def validar_teoria(caso_texto: str, teoria_usuario: str, solucao: str) -> str:
    """
    Valida a teoria do usuário sobre o caso usando a API Gemini.
    Compara a teoria com a solução real (gabarito) e retorna o veredito.
    """
    try:
        # Prompt que pede à IA para comparar a teoria do usuário com a solução real
        prompt = (
            f"Aqui está o mistério: {caso_texto}\n\n"
            f"A solução real é: {solucao}\n\n"
            f"O usuário teorizou: {teoria_usuario}\n\n"
            "Compare a teoria com a solução real e dê o veredito final, explicando se o usuário acertou o culpado e os motivos."
        )

        # Lista padrão de modelos para tentar (mais recentes primeiro)
        model_names_padrao = [
            "gemini-1.5-flash",
            "gemini-1.5-pro",
            "gemini-pro",
        ]
        
        last_error = None
        chaves_tentadas = set()
        max_tentativas_chaves = len(API_KEYS)
        erro_429_encontrado = False
        modelos_disponiveis_cache = None
        
        # Tenta cada chave da API (rodízio)
        for tentativa_chave in range(max_tentativas_chaves):
            api_key = _obter_proxima_chave()
            
            # Evita tentar a mesma chave múltiplas vezes na mesma requisição
            if api_key in chaves_tentadas:
                continue
            chaves_tentadas.add(api_key)
            
            # Tenta listar modelos disponíveis na primeira tentativa
            if modelos_disponiveis_cache is None:
                try:
                    modelos_disponiveis_cache = _listar_modelos_disponiveis(api_key)
                    if modelos_disponiveis_cache:
                        print(f"✅ Modelos disponíveis encontrados: {', '.join(modelos_disponiveis_cache[:3])}...")
                except Exception:
                    # Se falhar, segue usando a lista padrão
                    pass
            
            # Usa modelos disponíveis se encontrados, senão usa a lista padrão
            model_names = modelos_disponiveis_cache if modelos_disponiveis_cache else model_names_padrao
            
            erro_429_encontrado = False
            
            # Tenta cada combinação de versão de API e modelo
            for api_url in GEMINI_API_URLS:
                if erro_429_encontrado:
                    break
                    
                for model_name in model_names:
                    try:
                        # Usa a API REST diretamente para validar a teoria
                        url = f"{api_url}/{model_name}:generateContent"
                        headers = {
                            "Content-Type": "application/json",
                        }
                        payload = {
                            "contents": [{
                                "parts": [{
                                    "text": prompt
                                }]
                            }]
                        }
                        
                        response = requests.post(
                            url,
                            headers=headers,
                            json=payload,
                            params={"key": api_key}
                        )
                        
                        response.raise_for_status()
                        data = response.json()
                        
                        # Extrai o texto da resposta
                        if "candidates" in data and len(data["candidates"]) > 0:
                            candidate = data["candidates"][0]
                            if "content" in candidate and "parts" in candidate["content"]:
                                texto_resposta = candidate["content"]["parts"][0].get("text", "")
                                if texto_resposta:
                                    return texto_resposta.strip()
                        
                    except requests.exceptions.HTTPError as e:
                        status_code = e.response.status_code if e.response else None
                        
                        # Se for 429 (limite atingido), tenta a próxima chave
                        if status_code == 429:
                            print("⚠️ Limite de requisições atingido (429) para a chave atual. Tentando próxima chave...")
                            last_error = e
                            erro_429_encontrado = True
                            break
                        
                        # Se for 404, tenta o próximo modelo
                        if status_code == 404:
                            last_error = e
                            continue
                        
                        # Para outros erros HTTP, propaga
                        raise e
                    
                    except Exception as e:
                        last_error = e
                        # Se o erro não for 404, para de tentar outros modelos
                        if "404" not in str(e) and "NOT_FOUND" not in str(e):
                            raise e
                        continue
            
            # Se não foi 429, não precisa tentar outras chaves (sucesso ou outro erro)
            if not erro_429_encontrado:
                break
        
        # Se chegou aqui, nenhum modelo funcionou ou todas as chaves atingiram limite
        raise last_error if last_error else Exception("Nenhum modelo disponível")

    except Exception as e:
        mensagem = str(e)
        status_code = None
        
        # Tenta extrair o código de status do erro
        if hasattr(e, 'response') and e.response:
            status_code = e.response.status_code

        if status_code == 429 or "429" in mensagem:
            print("⚠️ Limite de requisições atingido (429) em todas as chaves. Aguarde um minuto e tente novamente.")
        else:
            print(f"❌ Erro ao chamar a API Gemini: {mensagem}")

        return None
