class CasoCriminal:
    """
    Representa um caso criminal gerado pela IA com todas as informações principais.
    """

    def __init__(self, genero, titulo, descricao, pistas, suspeitos):
        """
        Inicializa um novo caso criminal com gênero, título, descrição, pistas e suspeitos.
        """
        self.genero = genero
        self.titulo = titulo
        self.descricao = descricao
        self.pistas = pistas
        self.suspeitos = suspeitos