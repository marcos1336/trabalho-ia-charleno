class CasoCriminal:
    def __init__(self, genero, titulo, descricao, pistas, suspeitos):
        self.genero = genero
        self.titulo = titulo
        self.descricao = descricao
        self.pistas = pistas
        self.suspeitos = suspeitos