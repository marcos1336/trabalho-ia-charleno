from fastapi import FastAPI, Request, Form
from fastapi.templating import Jinja2Templates
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse

from app.services.gemini_service import gerar_caso, validar_teoria

app = FastAPI(title="Cabeça de Ovo - Gerador de Casos")

# Arquivos estáticos (CSS, JS, imagens)
app.mount(
    "/static",
    StaticFiles(directory="app/static"),
    name="static"
)

# Templates HTML
templates = Jinja2Templates(directory="app/templates")


@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    """
    Página inicial
    """
    return templates.TemplateResponse(
        "index.html",
        {"request": request}
    )


@app.post("/gerar", response_class=HTMLResponse)
async def processar_geracao(
    request: Request,
    genero: str = Form(...)
):
    """
    Processa o formulário e gera o caso criminal
    """
    resultado = gerar_caso(genero)

    if not resultado:
        return templates.TemplateResponse(
            "resultado.html",
            {
                "request": request,
                "genero": genero,
                "titulo": "Erro de Conexão",
                "descricao": (
                    "Não foi possível gerar o caso no momento. "
                    "Verifique sua chave da API ou tente novamente em instantes."
                ),
                "solucao": "",
                "pistas": [],
                "suspeitos": []
            }
        )

    return templates.TemplateResponse(
        "resultado.html",
        {
            "request": request,
            **resultado
        }
    )


@app.post("/validar", response_class=HTMLResponse)
async def processar_validacao(
    request: Request,
    genero: str = Form(...),
    descricao: str = Form(...),
    teoria: str = Form(...),
    solucao: str = Form(...)
):
    """
    Processa a validação da teoria do usuário
    """
    # Monta o texto do caso para enviar à IA
    caso_texto = f"Gênero: {genero}\n\nDescrição: {descricao}"
    
    resultado_validacao = validar_teoria(caso_texto, teoria, solucao)
    
    if not resultado_validacao:
        return templates.TemplateResponse(
            "veredito.html",
            {
                "request": request,
                "teoria": teoria,
                "analise": (
                    "Não foi possível validar a teoria no momento. "
                    "Verifique sua chave da API ou tente novamente em instantes."
                )
            }
        )
    
    return templates.TemplateResponse(
        "veredito.html",
        {
            "request": request,
            "teoria": teoria,
            "analise": resultado_validacao
        }
    )
